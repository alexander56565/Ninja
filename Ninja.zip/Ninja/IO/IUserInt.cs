﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ninja
{
    public interface IUserInt
    {
        string ReadLine();
        void WriteLine(string output);
    }
}
