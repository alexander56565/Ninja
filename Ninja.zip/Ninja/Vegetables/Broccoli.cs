﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ninja
{
    public class Broccoli : Vegetable
    {
        public Broccoli()
        {
            this.Delay = 3;
            this.PowerEffect = 10;
            this.StaminaEffect = 0;
        }  
    }
}
