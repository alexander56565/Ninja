﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ninja 
{
    public class BlankSpace : Vegetable
    {
        public BlankSpace()
        {
            this.Delay = 0;
            this.PowerEffect = 0;
            this.StaminaEffect = 0;
        }   

    }
}
